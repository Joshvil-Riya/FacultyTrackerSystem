/**
 * Faculty Tracker
 * A comprehensive JavaScript implementation with advanced features 
 */

// ==================== //
// Data Management
// ==================== //

/**
 * Faculty Data Model
 */
class FacultyModel {
  constructor() {
    this.faculty = this.loadFaculty();
  }

  /**
   * Load faculty data from localStorage
   */
  loadFaculty() {
    const storedFaculty = localStorage.getItem('facultyData');
    return storedFaculty ? JSON.parse(storedFaculty) : this.getSampleData();
  }

  /**
   * Save faculty data to localStorage
   */
  saveFaculty() {
    localStorage.setItem('facultyData', JSON.stringify(this.faculty));
  }

  /**
   * Get all faculty members
   */
  getAllFaculty() {
    return [...this.faculty];
  }

  /**
   * Get a faculty member by ID
   */
  getFacultyById(id) {
    return this.faculty.find(faculty => faculty.id === id);
  }

  /**
   * Add a new faculty member
   */
  addFaculty(faculty) {
    const newFaculty = {
      ...faculty,
      id: this.generateId(),
      createdAt: new Date().toISOString()
    };
    
    this.faculty.push(newFaculty);
    this.saveFaculty();
    return newFaculty;
  }

  /**
   * Update an existing faculty member
   */
  updateFaculty(id, updatedFaculty) {
    const index = this.faculty.findIndex(faculty => faculty.id === id);
    if (index !== -1) {
      this.faculty[index] = {
        ...this.faculty[index],
        ...updatedFaculty,
        updatedAt: new Date().toISOString()
      };
      this.saveFaculty();
      return this.faculty[index];
    }
    return null;
  }

  /**
   * Delete a faculty member
   */
  deleteFaculty(id) {
    const index = this.faculty.findIndex(faculty => faculty.id === id);
    if (index !== -1) {
      this.faculty.splice(index, 1);
      this.saveFaculty();
      return true;
    }
    return false;
  }

  /**
   * Generate a unique ID for a new faculty member
   */
  generateId() {
    return Date.now().toString(36) + Math.random().toString(36).substr(2, 5);
  }

  /**
   * Filter faculty by search term and filters
   */
  filterFaculty(searchTerm, department, position, status) {
    return this.faculty.filter(faculty => {
      // Search term filter
      const searchMatches = !searchTerm || 
        faculty.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        faculty.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
        faculty.department.toLowerCase().includes(searchTerm.toLowerCase());
      
      // Department filter
      const departmentMatches = !department || faculty.department === department;
      
      // Position filter
      const positionMatches = !position || faculty.position === position;
      
      // Status filter
      const statusMatches = !status || faculty.status === status;
      
      return searchMatches && departmentMatches && positionMatches && statusMatches;
    });
  }

  /**
   * Get statistics about faculty
   */
  getStatistics() {
    const totalFaculty = this.faculty.length;
    
    // Count unique departments
    const departments = new Set(this.faculty.map(f => f.department));
    const departmentCount = departments.size;
    
    // Count active faculty
    const activeFaculty = this.faculty.filter(f => f.status === 'Active').length;
    
    // Count professors (all kinds)
    const professors = this.faculty.filter(f => 
      f.position.includes('Professor')
    ).length;
    
    return {
      totalFaculty,
      departmentCount,
      activeFaculty,
      professors
    };
  }

  /**
   * Get sample data for initial load
   */
  getSampleData() {
    return [
      {
        id: '1',
        name: 'Dr. Jane Smith',
        email: 'jane.smith@university.edu',
        phone: '(555) 123-4567',
        department: 'Computer Science',
        position: 'Professor',
        status: 'Active',
        joinDate: '2015-09-01',
        bio: 'Dr. Smith specializes in artificial intelligence and machine learning. She has published over 50 papers in top-tier conferences and journals.',
        photo: 'https://randomuser.me/api/portraits/women/1.jpg',
        createdAt: '2023-01-01T12:00:00Z'
      },
      {
        id: '2',
        name: 'Dr. Michael Johnson',
        email: 'michael.johnson@university.edu',
        phone: '(555) 234-5678',
        department: 'Physics',
        position: 'Associate Professor',
        status: 'Active',
        joinDate: '2017-01-15',
        bio: 'Dr. Johnson focuses on quantum mechanics and theoretical physics. He leads the Quantum Computing Research Group.',
        photo: 'https://randomuser.me/api/portraits/men/1.jpg',
        createdAt: '2023-01-02T12:00:00Z'
      },
      {
        id: '3',
        name: 'Dr. Sarah Williams',
        email: 'sarah.williams@university.edu',
        phone: '(555) 345-6789',
        department: 'Mathematics',
        position: 'Assistant Professor',
        status: 'On Leave',
        joinDate: '2019-08-20',
        bio: 'Dr. Williams researches advanced topics in number theory and cryptography. She is currently on sabbatical researching at ETH Zurich.',
        photo: 'https://randomuser.me/api/portraits/women/2.jpg',
        createdAt: '2023-01-03T12:00:00Z'
      },
      {
        id: '4',
        name: 'Prof. Robert Chen',
        email: 'robert.chen@university.edu',
        phone: '(555) 456-7890',
        department: 'Chemistry',
        position: 'Professor',
        status: 'Active',
        joinDate: '2010-03-10',
        bio: 'Prof. Chen is a renowned chemical engineer with multiple patents in sustainable materials. He heads the Material Sciences Laboratory.',
        photo: 'https://randomuser.me/api/portraits/men/2.jpg',
        createdAt: '2023-01-04T12:00:00Z'
      }
    ];
  }
}

// ==================== //
// Form Validation
// ==================== //

/**
 * Form validation utilities
 */
class Validator {
  /**
   * Validate a text field (required and minimum length)
   */
  static validateText(value, minLength = 2) {
    if (!value || value.trim() === '') {
      return 'This field is required';
    }
    
    if (value.length < minLength) {
      return `Must be at least ${minLength} characters`;
    }
    
    return null;
  }
  
  /**
   * Validate an email address
   */
  static validateEmail(email) {
    if (!email || email.trim() === '') {
      return 'Email is required';
    }
    
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      return 'Please enter a valid email address';
    }
    
    return null;
  }
  
  /**
   * Validate a phone number
   */
  static validatePhone(phone) {
    if (!phone || phone.trim() === '') {
      return 'Phone number is required';
    }
    
    // Simple phone validation (allows various formats)
    const phoneRegex = /^[\d\s\-\(\)\.+]{10,20}$/;
    if (!phoneRegex.test(phone)) {
      return 'Please enter a valid phone number';
    }
    
    return null;
  }
  
  /**
   * Validate a date field
   */
  static validateDate(date) {
    if (!date || date.trim() === '') {
      return 'Date is required';
    }
    
    const selectedDate = new Date(date);
    const currentDate = new Date();
    
    if (selectedDate > currentDate) {
      return 'Date cannot be in the future';
    }
    
    return null;
  }
  
  /**
   * Validate a select field
   */
  static validateSelect(value) {
    if (!value || value.trim() === '') {
      return 'Please select an option';
    }
    
    return null;
  }
  
  /**
   * Show error message for a field
   */
  static showError(fieldId, errorMessage) {
    const field = document.getElementById(fieldId);
    const errorElement = document.getElementById(`${fieldId}-error`);
    
    if (field && errorElement) {
      field.classList.add('error');
      errorElement.textContent = errorMessage;
      errorElement.classList.add('visible');
    }
  }
  
  /**
   * Clear error message for a field
   */
  static clearError(fieldId) {
    const field = document.getElementById(fieldId);
    const errorElement = document.getElementById(`${fieldId}-error`);
    
    if (field && errorElement) {
      field.classList.remove('error');
      errorElement.textContent = '';
      errorElement.classList.remove('visible');
    }
  }
  
  /**
   * Validate the faculty form
   */
  static validateFacultyForm() {
    let isValid = true;
    
    // Clear all previous errors
    const errorElements = document.querySelectorAll('.error-message');
    errorElements.forEach(el => {
      el.textContent = '';
      el.classList.remove('visible');
    });
    
    // Get all form fields
    const nameField = document.getElementById('faculty-name');
    const emailField = document.getElementById('faculty-email');
    const phoneField = document.getElementById('faculty-phone');
    const departmentField = document.getElementById('faculty-department');
    const positionField = document.getElementById('faculty-position');
    const joinDateField = document.getElementById('faculty-join-date');
    
    // Validate name
    const nameError = this.validateText(nameField.value, 3);
    if (nameError) {
      this.showError('faculty-name', nameError);
      isValid = false;
    }
    
    // Validate email
    const emailError = this.validateEmail(emailField.value);
    if (emailError) {
      this.showError('faculty-email', emailError);
      isValid = false;
    }
    
    // Validate phone
    const phoneError = this.validatePhone(phoneField.value);
    if (phoneError) {
      this.showError('faculty-phone', phoneError);
      isValid = false;
    }
    
    // Validate department
    const departmentError = this.validateSelect(departmentField.value);
    if (departmentError) {
      this.showError('faculty-department', departmentError);
      isValid = false;
    }
    
    // Validate position
    const positionError = this.validateSelect(positionField.value);
    if (positionError) {
      this.showError('faculty-position', positionError);
      isValid = false;
    }
    
    // Validate join date
    const dateError = this.validateDate(joinDateField.value);
    if (dateError) {
      this.showError('faculty-join-date', dateError);
      isValid = false;
    }
    
    return isValid;
  }
}

// ==================== //
// UI Component
// ==================== //

/**
 * UI Controller for Faculty Tracker
 */
class FacultyUI {
  constructor(facultyModel) {
    this.facultyModel = facultyModel;
    this.facultyGrid = document.getElementById('faculty-grid');
    this.emptyState = document.getElementById('empty-state');
    this.currentEditId = null;
    
    // Initialize the UI
    this.init();
  }
  
  /**
   * Initialize the UI
   */
  init() {
    this.initEventHandlers();
    this.renderFacultyGrid();
    this.updateStatistics();
    this.setupPhotoPreview();
  }
  
  /**
   * Initialize all event handlers
   */
  initEventHandlers() {
    // Add Faculty Buttons
    document.getElementById('add-faculty-btn').addEventListener('click', () => this.showAddFacultyModal());
    document.getElementById('banner-add-btn').addEventListener('click', () => this.showAddFacultyModal());
    document.getElementById('empty-add-btn').addEventListener('click', () => this.showAddFacultyModal());
    
    // Statistics Button
    document.getElementById('statistics-btn').addEventListener('click', () => this.toggleStatistics());
    
    // Faculty Form
    document.getElementById('faculty-form').addEventListener('submit', (e) => this.handleFormSubmit(e));
    document.getElementById('cancel-faculty').addEventListener('click', () => this.hideModal('faculty-modal'));
    
    // Photo Preview
    document.getElementById('faculty-photo').addEventListener('change', (e) => this.updatePhotoPreview(e.target.value));
    
    // View Faculty Modal
    document.getElementById('view-close-btn').addEventListener('click', () => this.hideModal('view-modal'));
    document.getElementById('close-view-modal').addEventListener('click', () => this.hideModal('view-modal'));
    document.getElementById('view-edit-btn').addEventListener('click', () => this.handleViewEditClick());
    
    // Delete Faculty Modal
    document.getElementById('cancel-delete-btn').addEventListener('click', () => this.hideModal('delete-modal'));
    document.getElementById('close-delete-modal').addEventListener('click', () => this.hideModal('delete-modal'));
    document.getElementById('confirm-delete-btn').addEventListener('click', () => this.handleDeleteFaculty());
    
    // Close Modals
    document.getElementById('close-modal').addEventListener('click', () => this.hideModal('faculty-modal'));
    document.querySelectorAll('.modal-backdrop').forEach(el => {
      el.addEventListener('click', (e) => {
        if (e.target === e.currentTarget) {
          this.hideAllModals();
        }
      });
    });
    
    // Search and Filter
    document.getElementById('search-input').addEventListener('input', (e) => this.handleSearch());
    document.getElementById('search-btn').addEventListener('click', () => this.handleSearch());
    document.getElementById('department-filter').addEventListener('change', () => this.handleSearch());
    document.getElementById('position-filter').addEventListener('change', () => this.handleSearch());
    document.getElementById('status-filter').addEventListener('change', () => this.handleSearch());
  }
  
  /**
   * Render the faculty grid with all faculty members
   */
  renderFacultyGrid(facultyList = null) {
    // If no faculty list is provided, use all faculty
    const faculty = facultyList || this.facultyModel.getAllFaculty();
    
    // Clear the grid
    this.facultyGrid.innerHTML = '';
    
    if (faculty.length === 0) {
      this.emptyState.classList.add('visible');
      this.facultyGrid.classList.add('hidden');
    } else {
      this.emptyState.classList.remove('visible');
      this.facultyGrid.classList.remove('hidden');
      
      // Create faculty cards
      faculty.forEach(member => {
        const facultyCard = this.createFacultyCard(member);
        this.facultyGrid.appendChild(facultyCard);
      });
    }
  }
  
  /**
   * Create a faculty card element
   */
  createFacultyCard(faculty) {
    const card = document.createElement('div');
    card.className = 'faculty-card';
    card.setAttribute('data-id', faculty.id);
    
    // Determine status class - safely handle undefined status
    const status = faculty.status || 'Unknown';
    const statusClass = `status-${status.toLowerCase().replace(' ', '-')}`;
    
    card.innerHTML = `
      <div class="faculty-header">
        <img src="${faculty.photo || 'https://via.placeholder.com/150'}" alt="${faculty.name}" class="faculty-photo">
        <div class="faculty-name-position">
          <div class="faculty-name">${faculty.name}</div>
          <div class="faculty-position">${faculty.position}</div>
          <div class="faculty-status ${statusClass}">${status}</div>
        </div>
      </div>
      <div class="faculty-info">
        <div class="info-item">
          <div class="info-icon">
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
              <path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"></path>
            </svg>
          </div>
          <div class="info-label">Phone:</div>
          <div class="info-value">${faculty.phone}</div>
        </div>
        <div class="info-item">
          <div class="info-icon">
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
              <path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"></path>
              <polyline points="22,6 12,13 2,6"></polyline>
            </svg>
          </div>
          <div class="info-label">Email:</div>
          <div class="info-value">${faculty.email}</div>
        </div>
        <div class="info-item">
          <div class="info-icon">
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
              <rect x="2" y="7" width="20" height="14" rx="2" ry="2"></rect>
              <path d="M16 21V5a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v16"></path>
            </svg>
          </div>
          <div class="info-label">Department:</div>
          <div class="info-value">${faculty.department}</div>
        </div>
      </div>
      <div class="faculty-actions">
        <button class="btn btn-ghost btn-icon view-faculty" title="View Details">
          <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"></path>
            <circle cx="12" cy="12" r="3"></circle>
          </svg>
        </button>
        <button class="btn btn-ghost btn-icon edit-faculty" title="Edit Faculty">
          <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <path d="M17 3a2.828 2.828 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5L17 3z"></path>
          </svg>
        </button>
        <button class="btn btn-ghost btn-icon btn-danger delete-faculty" title="Delete Faculty">
          <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <polyline points="3 6 5 6 21 6"></polyline>
            <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path>
            <line x1="10" y1="11" x2="10" y2="17"></line>
            <line x1="14" y1="11" x2="14" y2="17"></line>
          </svg>
        </button>
      </div>
    `;
    
    // Add event listeners to buttons
    card.querySelector('.view-faculty').addEventListener('click', () => this.showViewFacultyModal(faculty.id));
    card.querySelector('.edit-faculty').addEventListener('click', () => this.showEditFacultyModal(faculty.id));
    card.querySelector('.delete-faculty').addEventListener('click', () => this.showDeleteFacultyModal(faculty.id));
    
    return card;
  }
  
  /**
   * Show the add faculty modal
   */
  showAddFacultyModal() {
    this.currentEditId = null;
    document.getElementById('modal-title').textContent = 'Add Faculty Member';
    document.getElementById('faculty-form').reset();
    document.getElementById('faculty-id').value = '';
    
    // Reset photo preview
    this.updatePhotoPreview('');
    
    // Set default join date to today
    const today = new Date().toISOString().split('T')[0];
    document.getElementById('faculty-join-date').value = today;
    
    this.showModal('faculty-modal');
  }
  
  /**
   * Show the edit faculty modal
   */
  showEditFacultyModal(id) {
    const faculty = this.facultyModel.getFacultyById(id);
    if (!faculty) return;
    
    this.currentEditId = id;
    document.getElementById('modal-title').textContent = 'Edit Faculty Member';
    document.getElementById('faculty-id').value = faculty.id;
    document.getElementById('faculty-name').value = faculty.name;
    document.getElementById('faculty-email').value = faculty.email;
    document.getElementById('faculty-phone').value = faculty.phone;
    document.getElementById('faculty-department').value = faculty.department;
    document.getElementById('faculty-position').value = faculty.position;
    document.getElementById('faculty-status').value = faculty.status;
    document.getElementById('faculty-join-date').value = faculty.joinDate;
    document.getElementById('faculty-bio').value = faculty.bio || '';
    document.getElementById('faculty-photo').value = faculty.photo || '';
    
    // Update photo preview
    this.updatePhotoPreview(faculty.photo || '');
    
    this.showModal('faculty-modal');
  }
  
  /**
   * Show the view faculty modal
   */
  showViewFacultyModal(id) {
    const faculty = this.facultyModel.getFacultyById(id);
    if (!faculty) return;
    
    const modalBody = document.getElementById('view-modal-body');
    document.getElementById('view-modal-title').textContent = faculty.name;
    
    // Determine status class - safely handle undefined status
    const status = faculty.status || 'Unknown';
    const statusClass = `status-${status.toLowerCase().replace(' ', '-')}`;
    
    // Format join date
    const joinDate = new Date(faculty.joinDate);
    const formattedDate = joinDate.toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
    
    modalBody.innerHTML = `
      <div class="faculty-profile">
        <div class="profile-header">
          <img src="${faculty.photo || 'https://via.placeholder.com/150'}" alt="${faculty.name}" class="profile-photo">
          <div class="profile-info">
            <div class="profile-name">${faculty.name}</div>
            <div class="profile-position">${faculty.position}</div>
            <div class="profile-status ${statusClass}">${status}</div>
          </div>
        </div>
        <div class="profile-details">
          <div class="detail-item">
            <div class="detail-label">Email</div>
            <div class="detail-value">${faculty.email}</div>
          </div>
          <div class="detail-item">
            <div class="detail-label">Phone</div>
            <div class="detail-value">${faculty.phone}</div>
          </div>
          <div class="detail-item">
            <div class="detail-label">Department</div>
            <div class="detail-value">${faculty.department}</div>
          </div>
          <div class="detail-item">
            <div class="detail-label">Join Date</div>
            <div class="detail-value">${formattedDate}</div>
          </div>
          ${faculty.bio ? `
            <div class="detail-item detail-bio">
              <div class="detail-label">Bio</div>
              <div class="detail-value">${faculty.bio}</div>
            </div>
          ` : ''}
        </div>
      </div>
    `;
    
    document.getElementById('view-edit-btn').setAttribute('data-id', faculty.id);
    
    this.showModal('view-modal');
  }
  
  /**
   * Show the delete faculty modal
   */
  showDeleteFacultyModal(id) {
    document.getElementById('delete-faculty-id').value = id;
    this.showModal('delete-modal');
  }
  
  /**
   * Handle form submission for adding/editing faculty
   */
  handleFormSubmit(e) {
    e.preventDefault();
    
    // Validate form
    if (!Validator.validateFacultyForm()) {
      return;
    }
    
    // Get form data
    const faculty = {
      name: document.getElementById('faculty-name').value,
      email: document.getElementById('faculty-email').value,
      phone: document.getElementById('faculty-phone').value,
      department: document.getElementById('faculty-department').value,
      position: document.getElementById('faculty-position').value,
      status: document.getElementById('faculty-status').value,
      joinDate: document.getElementById('faculty-join-date').value,
      bio: document.getElementById('faculty-bio').value,
      photo: document.getElementById('faculty-photo').value
    };
    
    // Check if adding or editing
    if (this.currentEditId) {
      this.facultyModel.updateFaculty(this.currentEditId, faculty);
    } else {
      this.facultyModel.addFaculty(faculty);
    }
    
    // Update UI
    this.renderFacultyGrid();
    this.updateStatistics();
    this.hideModal('faculty-modal');
    
    // Show success message
    this.showNotification(this.currentEditId ? 'Faculty updated successfully' : 'Faculty added successfully');
  }
  
  /**
   * Handle delete faculty confirmation
   */
  handleDeleteFaculty() {
    const id = document.getElementById('delete-faculty-id').value;
    
    if (id) {
      const success = this.facultyModel.deleteFaculty(id);
      
      if (success) {
        this.renderFacultyGrid();
        this.updateStatistics();
        this.hideModal('delete-modal');
        
        // Show success message
        this.showNotification('Faculty deleted successfully');
      }
    }
  }
  
  /**
   * Handle search and filtering
   */
  handleSearch() {
    const searchTerm = document.getElementById('search-input').value;
    const department = document.getElementById('department-filter').value;
    const position = document.getElementById('position-filter').value;
    const status = document.getElementById('status-filter').value;
    
    const filteredFaculty = this.facultyModel.filterFaculty(searchTerm, department, position, status);
    this.renderFacultyGrid(filteredFaculty);
  }
  
  /**
   * Handle view edit button click
   */
  handleViewEditClick() {
    const id = document.getElementById('view-edit-btn').getAttribute('data-id');
    this.hideModal('view-modal');
    this.showEditFacultyModal(id);
  }
  
  /**
   * Toggle statistics section
   */
  toggleStatistics() {
    const statsSection = document.getElementById('statistics-section');
    statsSection.classList.toggle('hidden');
  }
  
  /**
   * Update statistics display
   */
  updateStatistics() {
    const stats = this.facultyModel.getStatistics();
    
    document.getElementById('total-faculty-count').textContent = stats.totalFaculty;
    document.getElementById('department-count').textContent = stats.departmentCount;
    document.getElementById('active-faculty-count').textContent = stats.activeFaculty;
    document.getElementById('professor-count').textContent = stats.professors;
  }
  
  /**
   * Set up photo preview functionality
   */
  setupPhotoPreview() {
    const photoSelect = document.getElementById('faculty-photo');
    const photoPreview = document.getElementById('photo-preview');
    
    photoSelect.addEventListener('change', (e) => {
      this.updatePhotoPreview(e.target.value);
    });
  }
  
  /**
   * Update photo preview
   */
  updatePhotoPreview(photoUrl) {
    const photoPreview = document.getElementById('photo-preview');
    
    if (photoUrl) {
      photoPreview.innerHTML = `<img src="${photoUrl}" alt="Profile Preview">`;
    } else {
      photoPreview.innerHTML = `
        <div class="default-photo">
          <svg width="40" height="40" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <circle cx="9" cy="7" r="4" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          </svg>
        </div>
      `;
    }
  }
  
  /**
   * Show a notification message
   */
  showNotification(message, type = 'success') {
    // Create notification element if it doesn't exist
    let notification = document.getElementById('notification');
    
    if (!notification) {
      notification = document.createElement('div');
      notification.id = 'notification';
      notification.className = 'notification';
      document.body.appendChild(notification);
      
      // Add styles if not already in CSS
      const style = document.createElement('style');
      style.textContent = `
        .notification {
          position: fixed;
          bottom: 20px;
          right: 20px;
          padding: 12px 16px;
          border-radius: 4px;
          font-weight: 500;
          z-index: 9999;
          opacity: 0;
          transform: translateY(10px);
          transition: opacity 0.3s, transform 0.3s;
          box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
        }
        .notification.success {
          background-color: var(--color-success);
          color: white;
        }
        .notification.error {
          background-color: var(--color-error);
          color: white;
        }
        .notification.warning {
          background-color: var(--color-warning);
          color: white;
        }
        .notification.show {
          opacity: 1;
          transform: translateY(0);
        }
      `;
      document.head.appendChild(style);
    }
    
    // Set notification content and type
    notification.textContent = message;
    notification.className = `notification ${type}`;
    
    // Show notification
    setTimeout(() => {
      notification.classList.add('show');
    }, 10);
    
    // Hide notification after 3 seconds
    setTimeout(() => {
      notification.classList.remove('show');
    }, 3000);
  }
  
  /**
   * Show a modal
   */
  showModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
      // Hide all other modals first
      this.hideAllModals();
      
      // Show this modal
      modal.classList.add('visible');
      document.body.style.overflow = 'hidden';
    }
  }
  
  /**
   * Hide a modal
   */
  hideModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
      modal.classList.remove('visible');
      document.body.style.overflow = '';
    }
  }
  
  /**
   * Hide all modals
   */
  hideAllModals() {
    const modals = document.querySelectorAll('.modal');
    modals.forEach(modal => {
      modal.classList.remove('visible');
    });
    document.body.style.overflow = '';
  }
}

// ==================== //
// Initialize Application
// ==================== //

/**
 * Initialize the application when DOM is loaded
 */
document.addEventListener('DOMContentLoaded', () => {
  const facultyModel = new FacultyModel();
  const facultyUI = new FacultyUI(facultyModel);
});